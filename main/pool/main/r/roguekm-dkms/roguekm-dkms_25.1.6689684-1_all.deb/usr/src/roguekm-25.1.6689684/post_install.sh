#!/bin/sh

. ./common_defs.sh

# Load the module when booting.
cat <<- END > ${AUTOLOAD_CONF}
	${MODULE}
END
