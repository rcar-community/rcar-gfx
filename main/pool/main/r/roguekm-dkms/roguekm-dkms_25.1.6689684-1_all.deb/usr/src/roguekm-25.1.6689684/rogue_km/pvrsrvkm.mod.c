#include <linux/module.h>
#include <linux/export-internal.h>
#include <linux/compiler.h>

MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

KSYMTAB_FUNC(RGXHWPerfConnect, "", "");
KSYMTAB_FUNC(RGXHWPerfDisconnect, "", "");
KSYMTAB_FUNC(RGXHWPerfControl, "", "");
KSYMTAB_FUNC(RGXHWPerfConfigureCounters, "", "");
KSYMTAB_FUNC(RGXHWPerfDisableCounters, "", "");
KSYMTAB_FUNC(RGXHWPerfAcquireEvents, "", "");
KSYMTAB_FUNC(RGXHWPerfReleaseEvents, "", "");
KSYMTAB_FUNC(RGXHWPerfConvertCRTimeStamp, "", "");

MODULE_INFO(depends, "");

MODULE_ALIAS("of:N*T*Crenesas,gsx");
MODULE_ALIAS("of:N*T*Crenesas,gsxC*");
MODULE_ALIAS("platform:pvrsrvkm");
