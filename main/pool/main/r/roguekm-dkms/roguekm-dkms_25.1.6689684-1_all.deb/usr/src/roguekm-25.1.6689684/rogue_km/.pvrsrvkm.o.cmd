savedcmd_pvrsrvkm.o := aarch64-linux-gnu-ld -EL  -maarch64elf -z noexecstack   -r -o pvrsrvkm.o @pvrsrvkm.mod 
