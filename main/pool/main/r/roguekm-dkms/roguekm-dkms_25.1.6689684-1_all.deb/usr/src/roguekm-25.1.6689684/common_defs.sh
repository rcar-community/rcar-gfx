# Common definitions for DKMS scripts

MODULE="pvrsrvkm"
AUTOLOAD_DIR="/usr/lib/modules-load.d"
AUTOLOAD_CONF="${AUTOLOAD_DIR}/${MODULE}.conf"
