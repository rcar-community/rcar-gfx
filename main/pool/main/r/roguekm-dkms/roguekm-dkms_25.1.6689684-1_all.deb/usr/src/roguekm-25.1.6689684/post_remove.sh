#!/bin/sh

. ./common_defs.sh

# The module is being removed. If there are no instances of the module left,
# then it no longer needs to be loaded when booting.
find /lib/modules -name pvrsrvkm.ko -exec false {} + && \
	rm -f ${AUTOLOAD_CONF}
