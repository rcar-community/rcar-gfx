savedcmd_generated/volcanic/sync_bridge/client_sync_direct_bridge.o := aarch64-linux-gnu-gcc -Wp,-MMD,generated/volcanic/sync_bridge/.client_sync_direct_bridge.o.d -nostdinc -I/work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include -I/work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/generated -I/work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include -I/work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include -I/work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/uapi -I/work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/generated/uapi -I/work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi -I/work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/generated/uapi -include /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/compiler-version.h -include /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/kconfig.h -include /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/compiler_types.h -D__KERNEL__ -mlittle-endian -DKASAN_SHADOW_SCALE_SHIFT= -fmacro-prefix-map=/work/github/pvr-linux-gitlab/rogue_km/binary_r8a779g_linux_nullws_drm_release/target_aarch64/kbuild/= -std=gnu11 -fshort-wchar -funsigned-char -fno-common -fno-PIE -fno-strict-aliasing -mgeneral-regs-only -DCONFIG_CC_HAS_K_CONSTRAINT=1 -Wno-psabi -mabi=lp64 -fno-asynchronous-unwind-tables -fno-unwind-tables -mbranch-protection=none -Wa,-march=armv8.5-a -DARM64_ASM_ARCH='"armv8.5-a"' -DKASAN_SHADOW_SCALE_SHIFT= -fno-delete-null-pointer-checks -O2 -fno-allow-store-data-races -fstack-protector-strong -fno-omit-frame-pointer -fno-optimize-sibling-calls -fno-stack-clash-protection -falign-functions=4 -fno-strict-overflow -fno-stack-check -fconserve-stack -fno-builtin-wcslen -Wall -Wextra -Wundef -Werror=implicit-function-declaration -Werror=implicit-int -Werror=return-type -Werror=strict-prototypes -Wno-format-security -Wno-trigraphs -Wno-frame-address -Wno-address-of-packed-member -Wmissing-declarations -Wmissing-prototypes -Wframe-larger-than=2048 -Wno-main -Wvla-larger-than=1 -Wno-pointer-sign -Wcast-function-type -Wno-array-bounds -Wno-stringop-overflow -Wno-alloc-size-larger-than -Wimplicit-fallthrough=5 -Werror=date-time -Werror=incompatible-pointer-types -Werror=designated-init -Wenum-conversion -Wunused -Wno-unused-but-set-variable -Wno-unused-const-variable -Wno-packed-not-aligned -Wno-format-overflow -Wno-format-truncation -Wno-stringop-truncation -Wno-override-init -Wno-missing-field-initializers -Wno-type-limits -Wno-shift-negative-value -Wno-maybe-uninitialized -Wno-sign-compare -Wno-unused-parameter -mstack-protector-guard=sysreg -mstack-protector-guard-reg=sp_el0 -mstack-protector-guard-offset=1072 -D__linux__ -include /work/github/pvr-linux-gitlab/rogue_km/binary_r8a779g_linux_nullws_drm_release/config_kernel.h -I/work/github/pvr-linux-gitlab/rogue_km/binary_r8a779g_linux_nullws_drm_release/include -DPVR_ARCH_VOLCANIC -DWINDOW_SYSTEM=\"nullws_drm\" -Iinclude -Iinclude/drm -I/work/github/pvr-linux-gitlab/rogue_km/services/shared/devices/volcanic -I/work/github/pvr-linux-gitlab/rogue_km/hwdefs/volcanic -I/work/github/pvr-linux-gitlab/rogue_km/hwdefs/volcanic/30.V.408.101 -I/work/github/pvr-linux-gitlab/rogue_km/include/drm -I/work/github/pvr-linux-gitlab/rogue_km/services/include/env/linux -I/work/github/pvr-linux-gitlab/rogue_km/services/server/env/linux/volcanic -I/work/github/pvr-linux-gitlab/rogue_km/services/server/env/linux -I/work/github/pvr-linux-gitlab/rogue_km/kernel/drivers/staging/imgtec -I/work/github/pvr-linux-gitlab/rogue_km/binary_r8a779g_linux_nullws_drm_release/target_neutral/intermediates/firmware -I/work/github/pvr-linux-gitlab/rogue_km/hwdefs/volcanic/km -I/work/github/pvr-linux-gitlab/rogue_km/include/volcanic -I/work/github/pvr-linux-gitlab/rogue_km/include -I/work/github/pvr-linux-gitlab/rogue_km/include/volcanic/public -I/work/github/pvr-linux-gitlab/rogue_km/include/public -I/work/github/pvr-linux-gitlab/rogue_km/services/include/volcanic -I/work/github/pvr-linux-gitlab/rogue_km/services/include -I/work/github/pvr-linux-gitlab/rogue_km/services/shared/include -I/work/github/pvr-linux-gitlab/rogue_km/services/server/devices/volcanic -I/work/github/pvr-linux-gitlab/rogue_km/services/server/devices -I/work/github/pvr-linux-gitlab/rogue_km/services/server/include/volcanic -I/work/github/pvr-linux-gitlab/rogue_km/services/server/include -I/work/github/pvr-linux-gitlab/rogue_km/services/shared/common -I/work/github/pvr-linux-gitlab/rogue_km/services/shared/devices -I/work/github/pvr-linux-gitlab/rogue_km/services/system/include -I/work/github/pvr-linux-gitlab/rogue_km/services/system/volcanic/include -I/work/github/pvr-linux-gitlab/rogue_km/services/server/common/volcanic -I/work/github/pvr-linux-gitlab/rogue_km/services/server/common -I/work/github/pvr-linux-gitlab/rogue_km/services/system/rgx_rcar -I/work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/mm_bridge -I/work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/cmm_bridge -I/work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/srvcore_bridge -I/work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/sync_bridge -I/work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/synctracking_bridge -I/work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/pvrtl_bridge -I/work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/cache_bridge -I/work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/dmabuf_bridge -I/work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/rgxtq2_bridge -I/work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/rgxta3d_bridge -I/work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/rgxhwperf_bridge -I/work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/rgxcmp_bridge -I/work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/rgxregconfig_bridge -I/work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/rgxtimerquery_bridge -I/work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/rgxfwdbg_bridge -I/work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/rgxray_bridge -I/work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/mmextmem_bridge -I/work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/devicememhistory_bridge -I/work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/synctracking_bridge -I/work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/di_bridge -Wno-ignored-qualifiers -Wno-error=cpp -DVOLCANIC_FBCDCV31 -Werror -Wno-address-of-packed-member -I/work/github/pvr-linux-gitlab/rogue_km/binary_r8a779g_linux_nullws_drm_release/target_aarch64/kbuild/. -I.  -DMODULE  -DKBUILD_BASENAME='"client_sync_direct_bridge"' -DKBUILD_MODNAME='"pvrsrvkm"' -D__KBUILD_MODNAME=kmod_pvrsrvkm -c -o generated/volcanic/sync_bridge/client_sync_direct_bridge.o generated/volcanic/sync_bridge/client_sync_direct_bridge.c  

source_generated/volcanic/sync_bridge/client_sync_direct_bridge.o := generated/volcanic/sync_bridge/client_sync_direct_bridge.c

deps_generated/volcanic/sync_bridge/client_sync_direct_bridge.o := \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/compiler-version.h \
    $(wildcard include/config/CC_VERSION_TEXT) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/kconfig.h \
    $(wildcard include/config/CPU_BIG_ENDIAN) \
    $(wildcard include/config/BOOGER) \
    $(wildcard include/config/FOO) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/compiler_types.h \
    $(wildcard include/config/DEBUG_INFO_BTF) \
    $(wildcard include/config/PAHOLE_HAS_BTF_TAG) \
    $(wildcard include/config/FUNCTION_ALIGNMENT) \
    $(wildcard include/config/CC_HAS_SANE_FUNCTION_ALIGNMENT) \
    $(wildcard include/config/X86_64) \
    $(wildcard include/config/ARM64) \
    $(wildcard include/config/LD_DEAD_CODE_DATA_ELIMINATION) \
    $(wildcard include/config/LTO_CLANG) \
    $(wildcard include/config/HAVE_ARCH_COMPILER_H) \
    $(wildcard include/config/CC_HAS_ASSUME) \
    $(wildcard include/config/CC_HAS_COUNTED_BY) \
    $(wildcard include/config/CC_HAS_MULTIDIMENSIONAL_NONSTRING) \
    $(wildcard include/config/UBSAN_INTEGER_WRAP) \
    $(wildcard include/config/CFI) \
    $(wildcard include/config/ARCH_USES_CFI_GENERIC_LLVM_PASS) \
    $(wildcard include/config/CC_HAS_ASM_INLINE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/compiler_attributes.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/compiler-gcc.h \
    $(wildcard include/config/ARCH_USE_BUILTIN_BSWAP) \
    $(wildcard include/config/SHADOW_CALL_STACK) \
    $(wildcard include/config/KCOV) \
    $(wildcard include/config/CC_HAS_TYPEOF_UNQUAL) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/compiler.h \
    $(wildcard include/config/ARM64_PTR_AUTH_KERNEL) \
    $(wildcard include/config/ARM64_PTR_AUTH) \
    $(wildcard include/config/BUILTIN_RETURN_ADDRESS_STRIPS_PAC) \
  /work/github/pvr-linux-gitlab/rogue_km/binary_r8a779g_linux_nullws_drm_release/config_kernel.h \
  generated/volcanic/sync_bridge/client_sync_bridge.h \
  include/img_defs.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/types.h \
    $(wildcard include/config/HAVE_UID16) \
    $(wildcard include/config/UID16) \
    $(wildcard include/config/ARCH_DMA_ADDR_T_64BIT) \
    $(wildcard include/config/PHYS_ADDR_T_64BIT) \
    $(wildcard include/config/64BIT) \
    $(wildcard include/config/ARCH_32BIT_USTAT_F_TINODE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/generated/uapi/asm/types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/asm-generic/types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/int-ll64.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/asm-generic/int-ll64.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/uapi/asm/bitsperlong.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/bitsperlong.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/asm-generic/bitsperlong.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/posix_types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/stddef.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/stddef.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/uapi/asm/posix_types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/asm-generic/posix_types.h \
  include/img_types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/generated/uapi/linux/version.h \
  include/kernel_types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/kernel.h \
    $(wildcard include/config/PREEMPT_VOLUNTARY_BUILD) \
    $(wildcard include/config/PREEMPT_DYNAMIC) \
    $(wildcard include/config/HAVE_PREEMPT_DYNAMIC_CALL) \
    $(wildcard include/config/HAVE_PREEMPT_DYNAMIC_KEY) \
    $(wildcard include/config/PREEMPT_) \
    $(wildcard include/config/DEBUG_ATOMIC_SLEEP) \
    $(wildcard include/config/SMP) \
    $(wildcard include/config/MMU) \
    $(wildcard include/config/PROVE_LOCKING) \
    $(wildcard include/config/TRACING) \
    $(wildcard include/config/DYNAMIC_FTRACE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/stdarg.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/align.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/vdso/align.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/vdso/const.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/const.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/array_size.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/compiler.h \
    $(wildcard include/config/TRACE_BRANCH_PROFILING) \
    $(wildcard include/config/PROFILE_ALL_BRANCHES) \
    $(wildcard include/config/OBJTOOL) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/rwonce.h \
    $(wildcard include/config/LTO) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/rwonce.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/kasan-checks.h \
    $(wildcard include/config/KASAN_GENERIC) \
    $(wildcard include/config/KASAN_SW_TAGS) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/kcsan-checks.h \
    $(wildcard include/config/KCSAN) \
    $(wildcard include/config/KCSAN_WEAK_MEMORY) \
    $(wildcard include/config/KCSAN_IGNORE_ATOMICS) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/limits.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/limits.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/vdso/limits.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/linkage.h \
    $(wildcard include/config/ARCH_USE_SYM_ANNOTATIONS) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/stringify.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/export.h \
    $(wildcard include/config/MODVERSIONS) \
    $(wildcard include/config/GENDWARFKSYMS) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/linkage.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/container_of.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/build_bug.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/bitops.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/bits.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/vdso/bits.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/bits.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/overflow.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/const.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/typecheck.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/kernel.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/sysinfo.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/bitops/generic-non-atomic.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/barrier.h \
    $(wildcard include/config/ARM64_PSEUDO_NMI) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/alternative-macros.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/cpucaps.h \
    $(wildcard include/config/ARM64_PAN) \
    $(wildcard include/config/ARM64_EPAN) \
    $(wildcard include/config/ARM64_SVE) \
    $(wildcard include/config/ARM64_SME) \
    $(wildcard include/config/ARM64_CNP) \
    $(wildcard include/config/ARM64_MTE) \
    $(wildcard include/config/ARM64_BTI) \
    $(wildcard include/config/ARM64_TLB_RANGE) \
    $(wildcard include/config/ARM64_POE) \
    $(wildcard include/config/ARM64_GCS) \
    $(wildcard include/config/ARM64_HAFT) \
    $(wildcard include/config/UNMAP_KERNEL_AT_EL0) \
    $(wildcard include/config/ARM64_ERRATUM_843419) \
    $(wildcard include/config/ARM64_ERRATUM_1742098) \
    $(wildcard include/config/ARM64_ERRATUM_2645198) \
    $(wildcard include/config/ARM64_ERRATUM_2658417) \
    $(wildcard include/config/CAVIUM_ERRATUM_23154) \
    $(wildcard include/config/NVIDIA_CARMEL_CNP_ERRATUM) \
    $(wildcard include/config/ARM64_WORKAROUND_REPEAT_TLBI) \
    $(wildcard include/config/ARM64_ERRATUM_3194386) \
    $(wildcard include/config/HW_PERF_EVENTS) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/generated/asm/cpucap-defs.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/insn-def.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/brk-imm.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/barrier.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/bitops.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/bitops/builtin-__ffs.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/bitops/builtin-ffs.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/bitops/builtin-__fls.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/bitops/builtin-fls.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/bitops/ffz.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/bitops/fls64.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/bitops/sched.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/bitops/hweight.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/bitops/arch_hweight.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/bitops/const_hweight.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/bitops/atomic.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/atomic.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/atomic.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/cmpxchg.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/lse.h \
    $(wildcard include/config/ARM64_LSE_ATOMICS) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/atomic_ll_sc.h \
    $(wildcard include/config/CC_HAS_K_CONSTRAINT) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/alternative.h \
    $(wildcard include/config/MODULES) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/init.h \
    $(wildcard include/config/MEMORY_HOTPLUG) \
    $(wildcard include/config/HAVE_ARCH_PREL32_RELOCATIONS) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/atomic_lse.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/atomic/atomic-arch-fallback.h \
    $(wildcard include/config/GENERIC_ATOMIC64) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/atomic/atomic-long.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/atomic/atomic-instrumented.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/instrumented.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/kmsan-checks.h \
    $(wildcard include/config/KMSAN) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/bitops/instrumented-atomic.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/bitops/lock.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/bitops/instrumented-lock.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/bitops/non-atomic.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/bitops/non-instrumented-non-atomic.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/bitops/le.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/uapi/asm/byteorder.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/byteorder/little_endian.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/byteorder/little_endian.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/swab.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/swab.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/generated/uapi/asm/swab.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/asm-generic/swab.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/byteorder/generic.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/bitops/ext2-atomic-setbit.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/hex.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/kstrtox.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/log2.h \
    $(wildcard include/config/ARCH_HAS_ILOG2_U32) \
    $(wildcard include/config/ARCH_HAS_ILOG2_U64) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/math.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/generated/asm/div64.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/div64.h \
    $(wildcard include/config/CC_OPTIMIZE_FOR_PERFORMANCE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/minmax.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/panic.h \
    $(wildcard include/config/PANIC_TIMEOUT) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/printk.h \
    $(wildcard include/config/MESSAGE_LOGLEVEL_DEFAULT) \
    $(wildcard include/config/CONSOLE_LOGLEVEL_DEFAULT) \
    $(wildcard include/config/CONSOLE_LOGLEVEL_QUIET) \
    $(wildcard include/config/EARLY_PRINTK) \
    $(wildcard include/config/PRINTK) \
    $(wildcard include/config/PRINTK_INDEX) \
    $(wildcard include/config/DYNAMIC_DEBUG) \
    $(wildcard include/config/DYNAMIC_DEBUG_CORE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/kern_levels.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/ratelimit_types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/param.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/uapi/asm/param.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/param.h \
    $(wildcard include/config/HZ) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/asm-generic/param.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/spinlock_types_raw.h \
    $(wildcard include/config/DEBUG_SPINLOCK) \
    $(wildcard include/config/DEBUG_LOCK_ALLOC) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/spinlock_types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/qspinlock_types.h \
    $(wildcard include/config/NR_CPUS) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/qrwlock_types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/lockdep_types.h \
    $(wildcard include/config/PROVE_RAW_LOCK_NESTING) \
    $(wildcard include/config/LOCKDEP) \
    $(wildcard include/config/LOCK_STAT) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/once_lite.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/sprintf.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/static_call_types.h \
    $(wildcard include/config/HAVE_STATIC_CALL) \
    $(wildcard include/config/HAVE_STATIC_CALL_INLINE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/instruction_pointer.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/util_macros.h \
    $(wildcard include/config/FOO_SUSPEND) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/wordpart.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/bug.h \
    $(wildcard include/config/GENERIC_BUG) \
    $(wildcard include/config/BUG_ON_DATA_CORRUPTION) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/bug.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/asm-bug.h \
    $(wildcard include/config/DEBUG_BUGVERBOSE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/bug.h \
    $(wildcard include/config/BUG) \
    $(wildcard include/config/GENERIC_BUG_RELATIVE_POINTERS) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/instrumentation.h \
    $(wildcard include/config/NOINSTR_VALIDATION) \
  include/pvrsrv_error.h \
  include/pvrsrv_errors.h \
  generated/volcanic/sync_bridge/common_sync_bridge.h \
  /work/github/pvr-linux-gitlab/rogue_km/include/public/powervr/mem_types.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/include/pdump.h \
  include/services_km.h \
  include/pdumpdefs.h \
  include/devicemem_typedefs.h \
  include/pvrsrv_memallocflags.h \
  include/pvrsrv_memalloc_physheap.h \
  include/pvrsrv_memallocflags_internal.h \
  include/pvrsrv_sync_km.h \
  /work/github/pvr-linux-gitlab/rogue_km/include/public/powervr/pvrsrv_sync_ext.h \
  include/pvr_debug.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/server/include/htbserver.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/include/htbuffer_types.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/include/htbuffer_sf.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/shared/include/sync.h \
  include/sync_prim_internal.h \
  include/dllist.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/shared/include/device_connection.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/server/env/linux/services_kernel_client.h \
  include/sync_checkpoint_external.h \
  /work/github/pvr-linux-gitlab/rogue_km/include/volcanic/rgx_fwif_km.h \
  /work/github/pvr-linux-gitlab/rogue_km/include/volcanic/rgx_fwif_shared.h \
  include/rgx_common.h \
  /work/github/pvr-linux-gitlab/rogue_km/hwdefs/volcanic/km/rgxdefs_km.h \
  /work/github/pvr-linux-gitlab/rogue_km/hwdefs/volcanic/km/cores/rgxcore_km_30.3.408.101.h \
  /work/github/pvr-linux-gitlab/rogue_km/hwdefs/volcanic/km/configs/rgxconfig_km_30.V.408.101.h \
  /work/github/pvr-linux-gitlab/rogue_km/hwdefs/volcanic/km/rgx_cr_defs_km.h \
  include/rgx_heap_firmware.h \
  include/rgx_common_asserts.h \
  /work/github/pvr-linux-gitlab/rogue_km/include/volcanic/rgx_hwperf.h \
  include/rgx_hwperf_common.h \
  include/pvrsrv_tlcommon.h \
  /work/github/pvr-linux-gitlab/rogue_km/include/volcanic/rgxheapconfig.h \
  /work/github/pvr-linux-gitlab/rogue_km/include/volcanic/rgx_fwif_customer.h \
  include/drm/pvr_drm.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/drm/drm.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/generated/uapi/asm/ioctl.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/ioctl.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/asm-generic/ioctl.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/drm/drm_mode.h \
  /work/github/pvr-linux-gitlab/rogue_km/kernel/drivers/staging/imgtec/pvr_dma_resv.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/dma-resv.h \
    $(wildcard include/config/DEBUG_MUTEXES) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/ww_mutex.h \
    $(wildcard include/config/PREEMPT_RT) \
    $(wildcard include/config/DEBUG_RT_MUTEXES) \
    $(wildcard include/config/DEBUG_WW_MUTEX_SLOWPATH) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/mutex.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/current.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/list.h \
    $(wildcard include/config/LIST_HARDENED) \
    $(wildcard include/config/DEBUG_LIST) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/poison.h \
    $(wildcard include/config/ILLEGAL_POINTER_VALUE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/spinlock_types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/rwlock_types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/lockdep.h \
    $(wildcard include/config/DEBUG_LOCKING_API_SELFTESTS) \
    $(wildcard include/config/PREEMPT_COUNT) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/smp.h \
    $(wildcard include/config/UP_LATE_INIT) \
    $(wildcard include/config/DEBUG_PREEMPT) \
    $(wildcard include/config/CSD_LOCK_WAIT_DEBUG) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/errno.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/errno.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/generated/uapi/asm/errno.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/asm-generic/errno.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/asm-generic/errno-base.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/cpumask.h \
    $(wildcard include/config/FORCE_NR_CPUS) \
    $(wildcard include/config/HOTPLUG_CPU) \
    $(wildcard include/config/DEBUG_PER_CPU_MAPS) \
    $(wildcard include/config/CPUMASK_OFFSTACK) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/cleanup.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/err.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/args.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/bitmap.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/find.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/string.h \
    $(wildcard include/config/BINARY_PRINTF) \
    $(wildcard include/config/FORTIFY_SOURCE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/string.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/string.h \
    $(wildcard include/config/ARCH_HAS_UACCESS_FLUSHCACHE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/bitmap-str.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/cpumask_types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/threads.h \
    $(wildcard include/config/BASE_SMALL) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/gfp_types.h \
    $(wildcard include/config/KASAN_HW_TAGS) \
    $(wildcard include/config/SLAB_OBJ_EXT) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/numa.h \
    $(wildcard include/config/NUMA_KEEP_MEMINFO) \
    $(wildcard include/config/NUMA) \
    $(wildcard include/config/HAVE_ARCH_NODE_DEV_GROUP) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/nodemask.h \
    $(wildcard include/config/HIGHMEM) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/nodemask_types.h \
    $(wildcard include/config/NODES_SHIFT) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/random.h \
    $(wildcard include/config/VMGENID) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/random.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/ioctl.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/irqnr.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/irqnr.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/smp_types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/llist.h \
    $(wildcard include/config/ARCH_HAVE_NMI_SAFE_CMPXCHG) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/preempt.h \
    $(wildcard include/config/TRACE_PREEMPT_TOGGLE) \
    $(wildcard include/config/PREEMPTION) \
    $(wildcard include/config/PREEMPT_NOTIFIERS) \
    $(wildcard include/config/PREEMPT_NONE) \
    $(wildcard include/config/PREEMPT_VOLUNTARY) \
    $(wildcard include/config/PREEMPT) \
    $(wildcard include/config/PREEMPT_LAZY) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/preempt.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/thread_info.h \
    $(wildcard include/config/THREAD_INFO_IN_TASK) \
    $(wildcard include/config/GENERIC_ENTRY) \
    $(wildcard include/config/ARCH_HAS_PREEMPT_LAZY) \
    $(wildcard include/config/HAVE_ARCH_WITHIN_STACK_FRAMES) \
    $(wildcard include/config/SH) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/restart_block.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/thread_info.h \
    $(wildcard include/config/ARM64_SW_TTBR0_PAN) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/memory.h \
    $(wildcard include/config/ARM64_VA_BITS) \
    $(wildcard include/config/ARM64_16K_PAGES) \
    $(wildcard include/config/KASAN_SHADOW_OFFSET) \
    $(wildcard include/config/KASAN) \
    $(wildcard include/config/ARM64_4K_PAGES) \
    $(wildcard include/config/RANDOMIZE_BASE) \
    $(wildcard include/config/DEBUG_VIRTUAL) \
    $(wildcard include/config/EFI) \
    $(wildcard include/config/ARM_GIC_V3_ITS) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/sizes.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/page-def.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/vdso/page.h \
    $(wildcard include/config/PAGE_SHIFT) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/mmdebug.h \
    $(wildcard include/config/DEBUG_VM) \
    $(wildcard include/config/DEBUG_VM_IRQSOFF) \
    $(wildcard include/config/DEBUG_VM_PGFLAGS) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/boot.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/sections.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/sections.h \
    $(wildcard include/config/HAVE_FUNCTION_DESCRIPTORS) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/sysreg.h \
    $(wildcard include/config/BROKEN_GAS_INST) \
    $(wildcard include/config/ARM64_PA_BITS_52) \
    $(wildcard include/config/ARM64_64K_PAGES) \
    $(wildcard include/config/AMPERE_ERRATUM_AC04_CPU_23) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/kasan-tags.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/gpr-num.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/generated/asm/sysreg-defs.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/bitfield.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/memory_model.h \
    $(wildcard include/config/FLATMEM) \
    $(wildcard include/config/SPARSEMEM_VMEMMAP) \
    $(wildcard include/config/SPARSEMEM) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/pfn.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/stack_pointer.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/smp.h \
    $(wildcard include/config/ARM64_ACPI_PARKING_PROTOCOL) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/percpu.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/percpu.h \
    $(wildcard include/config/HAVE_SETUP_PER_CPU_AREA) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/percpu-defs.h \
    $(wildcard include/config/ARCH_MODULE_NEEDS_WEAK_PER_CPU) \
    $(wildcard include/config/DEBUG_FORCE_WEAK_PER_CPU) \
    $(wildcard include/config/AMD_MEM_ENCRYPT) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/processor.h \
    $(wildcard include/config/COMPAT) \
    $(wildcard include/config/KUSER_HELPERS) \
    $(wildcard include/config/ARM64_FORCE_52BIT) \
    $(wildcard include/config/HAVE_HW_BREAKPOINT) \
    $(wildcard include/config/ARM64_TAGGED_ADDR_ABI) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/cache.h \
    $(wildcard include/config/ARCH_HAS_CACHE_LINE_SIZE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/vdso/cache.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/cache.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/kasan-enabled.h \
    $(wildcard include/config/ARCH_DEFER_KASAN) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/static_key.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/jump_label.h \
    $(wildcard include/config/JUMP_LABEL) \
    $(wildcard include/config/HAVE_ARCH_JUMP_LABEL_RELATIVE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/jump_label.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/insn.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/cputype.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/mte-def.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/vdso/processor.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/vdso/processor.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/cpufeature.h \
    $(wildcard include/config/ARM64_DEBUG_PRIORITY_MASKING) \
    $(wildcard include/config/ARM64_BTI_KERNEL) \
    $(wildcard include/config/ARM64_PA_BITS) \
    $(wildcard include/config/ARM64_HW_AFDBM) \
    $(wildcard include/config/ARM64_AMU_EXTN) \
    $(wildcard include/config/ARM64_LPA2) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/hwcap.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/uapi/asm/hwcap.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/hw_breakpoint.h \
    $(wildcard include/config/CPU_PM) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/virt.h \
    $(wildcard include/config/KVM) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/ptrace.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/uapi/asm/ptrace.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/uapi/asm/sve_context.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/irqchip/arm-gic-v3-prio.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/stacktrace/frame.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/kasan.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/mte-kasan.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/pgtable-types.h \
    $(wildcard include/config/PGTABLE_LEVELS) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/pgtable-nop4d.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/pgtable-hwdef.h \
    $(wildcard include/config/ARM64_CONT_PTE_SHIFT) \
    $(wildcard include/config/ARM64_CONT_PMD_SHIFT) \
    $(wildcard include/config/ARM64_VA_BITS_52) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/pointer_auth.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/prctl.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/spectre.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/fpsimd.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/uapi/asm/sigcontext.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/osq_lock.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/debug_locks.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/mutex_types.h \
    $(wildcard include/config/MUTEX_SPIN_ON_OWNER) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/rtmutex.h \
    $(wildcard include/config/RT_MUTEXES) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/rbtree_types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/dma-fence.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/wait.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/spinlock.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/irqflags.h \
    $(wildcard include/config/TRACE_IRQFLAGS) \
    $(wildcard include/config/IRQSOFF_TRACER) \
    $(wildcard include/config/PREEMPT_TRACER) \
    $(wildcard include/config/DEBUG_IRQFLAGS) \
    $(wildcard include/config/TRACE_IRQFLAGS_SUPPORT) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/irqflags_types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/irqflags.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/bottom_half.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/generated/asm/mmiowb.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/mmiowb.h \
    $(wildcard include/config/MMIOWB) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/spinlock.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/generated/asm/qspinlock.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/qspinlock.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/generated/asm/qrwlock.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/qrwlock.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/rwlock.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/spinlock_api_smp.h \
    $(wildcard include/config/INLINE_SPIN_LOCK) \
    $(wildcard include/config/INLINE_SPIN_LOCK_BH) \
    $(wildcard include/config/INLINE_SPIN_LOCK_IRQ) \
    $(wildcard include/config/INLINE_SPIN_LOCK_IRQSAVE) \
    $(wildcard include/config/INLINE_SPIN_TRYLOCK) \
    $(wildcard include/config/INLINE_SPIN_TRYLOCK_BH) \
    $(wildcard include/config/UNINLINE_SPIN_UNLOCK) \
    $(wildcard include/config/INLINE_SPIN_UNLOCK_BH) \
    $(wildcard include/config/INLINE_SPIN_UNLOCK_IRQ) \
    $(wildcard include/config/INLINE_SPIN_UNLOCK_IRQRESTORE) \
    $(wildcard include/config/GENERIC_LOCKBREAK) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/rwlock_api_smp.h \
    $(wildcard include/config/INLINE_READ_LOCK) \
    $(wildcard include/config/INLINE_WRITE_LOCK) \
    $(wildcard include/config/INLINE_READ_LOCK_BH) \
    $(wildcard include/config/INLINE_WRITE_LOCK_BH) \
    $(wildcard include/config/INLINE_READ_LOCK_IRQ) \
    $(wildcard include/config/INLINE_WRITE_LOCK_IRQ) \
    $(wildcard include/config/INLINE_READ_LOCK_IRQSAVE) \
    $(wildcard include/config/INLINE_WRITE_LOCK_IRQSAVE) \
    $(wildcard include/config/INLINE_READ_TRYLOCK) \
    $(wildcard include/config/INLINE_WRITE_TRYLOCK) \
    $(wildcard include/config/INLINE_READ_UNLOCK) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK) \
    $(wildcard include/config/INLINE_READ_UNLOCK_BH) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK_BH) \
    $(wildcard include/config/INLINE_READ_UNLOCK_IRQ) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK_IRQ) \
    $(wildcard include/config/INLINE_READ_UNLOCK_IRQRESTORE) \
    $(wildcard include/config/INLINE_WRITE_UNLOCK_IRQRESTORE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/kref.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/refcount.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/refcount_types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/sched.h \
    $(wildcard include/config/VIRT_CPU_ACCOUNTING_NATIVE) \
    $(wildcard include/config/SCHED_INFO) \
    $(wildcard include/config/SCHEDSTATS) \
    $(wildcard include/config/SCHED_CORE) \
    $(wildcard include/config/FAIR_GROUP_SCHED) \
    $(wildcard include/config/RT_GROUP_SCHED) \
    $(wildcard include/config/UCLAMP_TASK) \
    $(wildcard include/config/UCLAMP_BUCKETS_COUNT) \
    $(wildcard include/config/KMAP_LOCAL) \
    $(wildcard include/config/MEM_ALLOC_PROFILING) \
    $(wildcard include/config/SCHED_CLASS_EXT) \
    $(wildcard include/config/CGROUP_SCHED) \
    $(wildcard include/config/CFS_BANDWIDTH) \
    $(wildcard include/config/BLK_DEV_IO_TRACE) \
    $(wildcard include/config/PREEMPT_RCU) \
    $(wildcard include/config/TASKS_RCU) \
    $(wildcard include/config/TASKS_TRACE_RCU) \
    $(wildcard include/config/MEMCG_V1) \
    $(wildcard include/config/LRU_GEN) \
    $(wildcard include/config/COMPAT_BRK) \
    $(wildcard include/config/CGROUPS) \
    $(wildcard include/config/BLK_CGROUP) \
    $(wildcard include/config/PSI) \
    $(wildcard include/config/PAGE_OWNER) \
    $(wildcard include/config/EVENTFD) \
    $(wildcard include/config/ARCH_HAS_CPU_PASID) \
    $(wildcard include/config/X86_BUS_LOCK_DETECT) \
    $(wildcard include/config/TASK_DELAY_ACCT) \
    $(wildcard include/config/STACKPROTECTOR) \
    $(wildcard include/config/ARCH_HAS_SCALED_CPUTIME) \
    $(wildcard include/config/VIRT_CPU_ACCOUNTING_GEN) \
    $(wildcard include/config/NO_HZ_FULL) \
    $(wildcard include/config/POSIX_CPUTIMERS) \
    $(wildcard include/config/POSIX_CPU_TIMERS_TASK_WORK) \
    $(wildcard include/config/KEYS) \
    $(wildcard include/config/SYSVIPC) \
    $(wildcard include/config/DETECT_HUNG_TASK) \
    $(wildcard include/config/IO_URING) \
    $(wildcard include/config/AUDIT) \
    $(wildcard include/config/AUDITSYSCALL) \
    $(wildcard include/config/DETECT_HUNG_TASK_BLOCKER) \
    $(wildcard include/config/UBSAN) \
    $(wildcard include/config/UBSAN_TRAP) \
    $(wildcard include/config/COMPACTION) \
    $(wildcard include/config/TASK_XACCT) \
    $(wildcard include/config/CPUSETS) \
    $(wildcard include/config/X86_CPU_RESCTRL) \
    $(wildcard include/config/FUTEX) \
    $(wildcard include/config/PERF_EVENTS) \
    $(wildcard include/config/NUMA_BALANCING) \
    $(wildcard include/config/RSEQ) \
    $(wildcard include/config/DEBUG_RSEQ) \
    $(wildcard include/config/SCHED_MM_CID) \
    $(wildcard include/config/FAULT_INJECTION) \
    $(wildcard include/config/LATENCYTOP) \
    $(wildcard include/config/KUNIT) \
    $(wildcard include/config/FUNCTION_GRAPH_TRACER) \
    $(wildcard include/config/MEMCG) \
    $(wildcard include/config/UPROBES) \
    $(wildcard include/config/BCACHE) \
    $(wildcard include/config/VMAP_STACK) \
    $(wildcard include/config/LIVEPATCH) \
    $(wildcard include/config/SECURITY) \
    $(wildcard include/config/BPF_SYSCALL) \
    $(wildcard include/config/KSTACK_ERASE) \
    $(wildcard include/config/KSTACK_ERASE_METRICS) \
    $(wildcard include/config/X86_MCE) \
    $(wildcard include/config/KRETPROBES) \
    $(wildcard include/config/RETHOOK) \
    $(wildcard include/config/ARCH_HAS_PARANOID_L1D_FLUSH) \
    $(wildcard include/config/RV) \
    $(wildcard include/config/RV_PER_TASK_MONITORS) \
    $(wildcard include/config/USER_EVENTS) \
    $(wildcard include/config/UNWIND_USER) \
    $(wildcard include/config/SCHED_PROXY_EXEC) \
    $(wildcard include/config/MEM_ALLOC_PROFILING_DEBUG) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/sched.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/pid_types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/sem_types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/shm.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/page.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/personality.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/personality.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/getorder.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/shmparam.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/shmparam.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/kmsan_types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/plist_types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/hrtimer_types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/timerqueue_types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/timer_types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/seccomp_types.h \
    $(wildcard include/config/SECCOMP) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/resource.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/resource.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/time_types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/generated/uapi/asm/resource.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/resource.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/asm-generic/resource.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/latencytop.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/sched/prio.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/sched/types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/signal_types.h \
    $(wildcard include/config/OLD_SIGACTION) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/signal.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/signal.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/uapi/asm/signal.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/signal.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/asm-generic/signal.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/asm-generic/signal-defs.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/generated/uapi/asm/siginfo.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/asm-generic/siginfo.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/syscall_user_dispatch_types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/mm_types_task.h \
    $(wildcard include/config/ARCH_WANT_BATCHED_UNMAP_TLB_FLUSH) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/tlbbatch.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/netdevice_xmit.h \
    $(wildcard include/config/NET_EGRESS) \
    $(wildcard include/config/NET_ACT_MIRRED) \
    $(wildcard include/config/NF_DUP_NETDEV) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/task_io_accounting.h \
    $(wildcard include/config/TASK_IO_ACCOUNTING) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/posix-timers_types.h \
    $(wildcard include/config/POSIX_TIMERS) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/rseq.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/seqlock_types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/kcsan.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/rv.h \
    $(wildcard include/config/RV_LTL_MONITOR) \
    $(wildcard include/config/RV_REACTORS) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/uidgid_types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/tracepoint-defs.h \
    $(wildcard include/config/TRACEPOINTS) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/unwind_deferred_types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/generated/asm/kmap_size.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/kmap_size.h \
    $(wildcard include/config/DEBUG_KMAP_LOCAL) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/generated/rq-offsets.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/sched/ext.h \
    $(wildcard include/config/EXT_GROUP_SCHED) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/rcupdate.h \
    $(wildcard include/config/TINY_RCU) \
    $(wildcard include/config/RCU_STRICT_GRACE_PERIOD) \
    $(wildcard include/config/RCU_LAZY) \
    $(wildcard include/config/RCU_STALL_COMMON) \
    $(wildcard include/config/VIRT_XFER_TO_GUEST_WORK) \
    $(wildcard include/config/RCU_NOCB_CPU) \
    $(wildcard include/config/TASKS_RCU_GENERIC) \
    $(wildcard include/config/TASKS_RUDE_RCU) \
    $(wildcard include/config/TREE_RCU) \
    $(wildcard include/config/DEBUG_OBJECTS_RCU_HEAD) \
    $(wildcard include/config/PROVE_RCU) \
    $(wildcard include/config/ARCH_WEAK_RELEASE_ACQUIRE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/context_tracking_irq.h \
    $(wildcard include/config/CONTEXT_TRACKING_IDLE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/rcutree.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/timekeeping.h \
    $(wildcard include/config/POSIX_AUX_CLOCKS) \
    $(wildcard include/config/GENERIC_CMOS_UPDATE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/clocksource_ids.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/ktime.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/jiffies.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/math64.h \
    $(wildcard include/config/ARCH_SUPPORTS_INT128) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/vdso/math64.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/time.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/time64.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/vdso/time64.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/time.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/time32.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/timex.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/timex.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/timex.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/arch_timer.h \
    $(wildcard include/config/ARM_ARCH_TIMER_OOL_WORKAROUND) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/percpu.h \
    $(wildcard include/config/RANDOM_KMALLOC_CACHES) \
    $(wildcard include/config/PAGE_SIZE_4KB) \
    $(wildcard include/config/NEED_PER_CPU_PAGE_FIRST_CHUNK) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/alloc_tag.h \
    $(wildcard include/config/MEM_ALLOC_PROFILING_ENABLED_BY_DEFAULT) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/codetag.h \
    $(wildcard include/config/CODE_TAGGING) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/clocksource/arm_arch_timer.h \
    $(wildcard include/config/ARM_ARCH_TIMER) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/timecounter.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/timex.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/vdso/time32.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/vdso/time.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/vdso/jiffies.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/generated/timeconst.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/vdso/ktime.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/slab.h \
    $(wildcard include/config/DEBUG_OBJECTS) \
    $(wildcard include/config/FAILSLAB) \
    $(wildcard include/config/KFENCE) \
    $(wildcard include/config/SLUB_TINY) \
    $(wildcard include/config/SLUB_DEBUG) \
    $(wildcard include/config/ZONE_DMA) \
    $(wildcard include/config/SLAB_BUCKETS) \
    $(wildcard include/config/KVFREE_RCU_BATCHED) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/gfp.h \
    $(wildcard include/config/ZONE_DMA32) \
    $(wildcard include/config/ZONE_DEVICE) \
    $(wildcard include/config/CONTIG_ALLOC) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/mmzone.h \
    $(wildcard include/config/ARCH_FORCE_MAX_ORDER) \
    $(wildcard include/config/PAGE_BLOCK_MAX_ORDER) \
    $(wildcard include/config/CMA) \
    $(wildcard include/config/MEMORY_ISOLATION) \
    $(wildcard include/config/ZSMALLOC) \
    $(wildcard include/config/UNACCEPTED_MEMORY) \
    $(wildcard include/config/IOMMU_SUPPORT) \
    $(wildcard include/config/SWAP) \
    $(wildcard include/config/HUGETLB_PAGE) \
    $(wildcard include/config/TRANSPARENT_HUGEPAGE) \
    $(wildcard include/config/LRU_GEN_STATS) \
    $(wildcard include/config/LRU_GEN_WALKS_MMU) \
    $(wildcard include/config/MEMORY_FAILURE) \
    $(wildcard include/config/PAGE_EXTENSION) \
    $(wildcard include/config/DEFERRED_STRUCT_PAGE_INIT) \
    $(wildcard include/config/HAVE_MEMORYLESS_NODES) \
    $(wildcard include/config/SPARSEMEM_EXTREME) \
    $(wildcard include/config/SPARSEMEM_VMEMMAP_PREINIT) \
    $(wildcard include/config/HAVE_ARCH_PFN_VALID) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/list_nulls.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/seqlock.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/pageblock-flags.h \
    $(wildcard include/config/HUGETLB_PAGE_SIZE_VARIABLE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/page-flags-layout.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/generated/bounds.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/sparsemem.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/pgtable-prot.h \
    $(wildcard include/config/HAVE_ARCH_USERFAULTFD_WP) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/rsi.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/rsi_cmds.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/arm-smccc.h \
    $(wildcard include/config/HAVE_ARM_SMCCC) \
    $(wildcard include/config/ARM) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/uuid.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/rsi_smc.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/mm_types.h \
    $(wildcard include/config/HAVE_ALIGNED_STRUCT_PAGE) \
    $(wildcard include/config/HUGETLB_PMD_PAGE_TABLE_SHARING) \
    $(wildcard include/config/SLAB_FREELIST_HARDENED) \
    $(wildcard include/config/USERFAULTFD) \
    $(wildcard include/config/ANON_VMA_NAME) \
    $(wildcard include/config/PER_VMA_LOCK) \
    $(wildcard include/config/HAVE_ARCH_COMPAT_MMAP_BASES) \
    $(wildcard include/config/MEMBARRIER) \
    $(wildcard include/config/FUTEX_PRIVATE_HASH) \
    $(wildcard include/config/ARCH_HAS_ELF_CORE_EFLAGS) \
    $(wildcard include/config/AIO) \
    $(wildcard include/config/MMU_NOTIFIER) \
    $(wildcard include/config/SPLIT_PMD_PTLOCKS) \
    $(wildcard include/config/IOMMU_MM_DATA) \
    $(wildcard include/config/KSM) \
    $(wildcard include/config/MM_ID) \
    $(wildcard include/config/CORE_DUMP_DEFAULT_ELF_HEADERS) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/auxvec.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/auxvec.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/uapi/asm/auxvec.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/rbtree.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/maple_tree.h \
    $(wildcard include/config/MAPLE_RCU_DISABLED) \
    $(wildcard include/config/DEBUG_MAPLE_TREE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/rwsem.h \
    $(wildcard include/config/RWSEM_SPIN_ON_OWNER) \
    $(wildcard include/config/DEBUG_RWSEMS) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/completion.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/swait.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/uprobes.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/timer.h \
    $(wildcard include/config/DEBUG_OBJECTS_TIMERS) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/debugobjects.h \
    $(wildcard include/config/DEBUG_OBJECTS_FREE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/workqueue.h \
    $(wildcard include/config/DEBUG_OBJECTS_WORK) \
    $(wildcard include/config/FREEZER) \
    $(wildcard include/config/SYSFS) \
    $(wildcard include/config/WQ_WATCHDOG) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/workqueue_types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/percpu_counter.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/mmu.h \
    $(wildcard include/config/ARM64_E0PD) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/page-flags.h \
    $(wildcard include/config/PAGE_IDLE_FLAG) \
    $(wildcard include/config/ARCH_USES_PG_ARCH_2) \
    $(wildcard include/config/ARCH_USES_PG_ARCH_3) \
    $(wildcard include/config/MIGRATION) \
    $(wildcard include/config/HUGETLB_PAGE_OPTIMIZE_VMEMMAP) \
    $(wildcard include/config/DEBUG_KMAP_LOCAL_FORCE_MAP) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/local_lock.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/local_lock_internal.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/zswap.h \
    $(wildcard include/config/ZSWAP) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/memory_hotplug.h \
    $(wildcard include/config/ARCH_HAS_ADD_PAGES) \
    $(wildcard include/config/MEMORY_HOTREMOVE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/notifier.h \
    $(wildcard include/config/TREE_SRCU) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/srcu.h \
    $(wildcard include/config/TINY_SRCU) \
    $(wildcard include/config/NEED_SRCU_NMI_SAFE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/rcu_segcblist.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/srcutree.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/rcu_node_tree.h \
    $(wildcard include/config/RCU_FANOUT) \
    $(wildcard include/config/RCU_FANOUT_LEAF) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/topology.h \
    $(wildcard include/config/USE_PERCPU_NUMA_NODE_ID) \
    $(wildcard include/config/SCHED_SMT) \
    $(wildcard include/config/GENERIC_ARCH_TOPOLOGY) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/arch_topology.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/topology.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/topology.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/percpu-refcount.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/hash.h \
    $(wildcard include/config/HAVE_ARCH_HASH) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/kasan.h \
    $(wildcard include/config/KASAN_STACK) \
    $(wildcard include/config/KASAN_VMALLOC) \
  /work/github/pvr-linux-gitlab/rogue_km/services/server/include/sync_server.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/server/include/pvrsrv.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/server/include/connection_server.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/server/include/handle.h \
  include/lock_types.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/shared/include/hash.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/server/include/handle_types.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/server/include/pvrsrv_cleanup.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/server/include/device.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/server/include/devicemem_heapcfg.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/server/include/mmu_common.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/server/include/pmr.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/include/physheap.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/server/include/opaque_types.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/server/include/pmr_impl.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/include/physheap_config.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/server/include/pvrsrv_device.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/server/include/rgx_firmware_boot.h \
  include/servicesext.h \
  include/img_3dtypes.h \
  /work/github/pvr-linux-gitlab/rogue_km/include/public/powervr/buffer_attribs.h \
  include/pvrsrv_device_types.h \
  include/cache_ops.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/shared/include/ra.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/server/include/pvr_notifier.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/server/include/pdump_mmu.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/server/include/pdump_symbolicaddr.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/server/include/sync_checkpoint.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/server/include/srvkm.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/shared/include/sync_internal.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/shared/include/lock.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/shared/include/allocmem.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/shared/include/devicemem.h \
  /work/github/pvr-linux-gitlab/rogue_km/hwdefs/volcanic/km/rgx_bvnc_defs_km.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/server/include/power.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/server/include/di_common.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/server/include/osconnection_server.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/server/include/osfunc.h \
  /work/github/pvr-linux-gitlab/rogue_km/kernel/drivers/staging/imgtec/kernel_nospec.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/nospec.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/io.h \
    $(wildcard include/config/HAS_IOPORT_MAP) \
    $(wildcard include/config/PCI) \
    $(wildcard include/config/STRICT_DEVMEM) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/io.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/pgtable.h \
    $(wildcard include/config/HIGHPTE) \
    $(wildcard include/config/ARCH_HAS_NONLEAF_PMD_YOUNG) \
    $(wildcard include/config/ARCH_HAS_HW_PTE_YOUNG) \
    $(wildcard include/config/GUP_GET_PXX_LOW_HIGH) \
    $(wildcard include/config/ARCH_WANT_PMD_MKWRITE) \
    $(wildcard include/config/HAVE_ARCH_TRANSPARENT_HUGEPAGE_PUD) \
    $(wildcard include/config/HAVE_ARCH_SOFT_DIRTY) \
    $(wildcard include/config/ARCH_ENABLE_THP_MIGRATION) \
    $(wildcard include/config/HAVE_ARCH_HUGE_VMAP) \
    $(wildcard include/config/X86_ESPFIX64) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/pgtable.h \
    $(wildcard include/config/DEBUG_PAGEALLOC) \
    $(wildcard include/config/ARCH_SUPPORTS_PMD_PFNMAP) \
    $(wildcard include/config/PAGE_TABLE_CHECK) \
    $(wildcard include/config/ARM64_CONTPTE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/proc-fns.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/mte.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/tlbflush.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/mmu_notifier.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/mmap_lock.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/sched/mm.h \
    $(wildcard include/config/MMU_LAZY_TLB_REFCOUNT) \
    $(wildcard include/config/ARCH_HAS_MEMBARRIER_CALLBACKS) \
    $(wildcard include/config/ARCH_HAS_SYNC_CORE_BEFORE_USERMODE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/sync_core.h \
    $(wildcard include/config/ARCH_HAS_PREPARE_SYNC_CORE_CMD) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/sched/coredump.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/interval_tree.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/fixmap.h \
    $(wildcard include/config/ACPI_APEI_GHES) \
    $(wildcard include/config/ARM_SDE_INTERFACE) \
    $(wildcard include/config/RELOCATABLE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/fixmap.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/por.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/page_table_check.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/pgtable_uffd.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/generated/asm/early_ioremap.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/early_ioremap.h \
    $(wildcard include/config/GENERIC_EARLY_IOREMAP) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/io.h \
    $(wildcard include/config/GENERIC_IOMAP) \
    $(wildcard include/config/TRACE_MMIO_ACCESS) \
    $(wildcard include/config/HAS_IOPORT) \
    $(wildcard include/config/GENERIC_IOREMAP) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/pci_iomap.h \
    $(wildcard include/config/NO_GENERIC_PCI_IOPORT_MAP) \
    $(wildcard include/config/GENERIC_PCI_IOMAP) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/logic_pio.h \
    $(wildcard include/config/INDIRECT_PIO) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/fwnode.h \
  include/osfunc_common.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/server/include/pvrsrv_pool.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/system/include/syscommon.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/system/rgx_rcar/sysinfo.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/platform_device.h \
    $(wildcard include/config/HAS_IOMEM) \
    $(wildcard include/config/SUSPEND) \
    $(wildcard include/config/HIBERNATE_CALLBACKS) \
    $(wildcard include/config/PM_SLEEP) \
    $(wildcard include/config/SUPERH) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/device.h \
    $(wildcard include/config/GENERIC_MSI_IRQ) \
    $(wildcard include/config/ENERGY_MODEL) \
    $(wildcard include/config/PINCTRL) \
    $(wildcard include/config/ARCH_HAS_DMA_OPS) \
    $(wildcard include/config/DMA_DECLARE_COHERENT) \
    $(wildcard include/config/DMA_CMA) \
    $(wildcard include/config/SWIOTLB) \
    $(wildcard include/config/SWIOTLB_DYNAMIC) \
    $(wildcard include/config/ARCH_HAS_SYNC_DMA_FOR_DEVICE) \
    $(wildcard include/config/ARCH_HAS_SYNC_DMA_FOR_CPU) \
    $(wildcard include/config/ARCH_HAS_SYNC_DMA_FOR_CPU_ALL) \
    $(wildcard include/config/DMA_OPS_BYPASS) \
    $(wildcard include/config/DMA_NEED_SYNC) \
    $(wildcard include/config/IOMMU_DMA) \
    $(wildcard include/config/PM) \
    $(wildcard include/config/OF) \
    $(wildcard include/config/DEVTMPFS) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/dev_printk.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/ratelimit.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/energy_model.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/kobject.h \
    $(wildcard include/config/UEVENT_HELPER) \
    $(wildcard include/config/DEBUG_KOBJECT_RELEASE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/sysfs.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/kernfs.h \
    $(wildcard include/config/KERNFS) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/idr.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/radix-tree.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/xarray.h \
    $(wildcard include/config/XARRAY_MULTI) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/uidgid.h \
    $(wildcard include/config/MULTIUSER) \
    $(wildcard include/config/USER_NS) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/highuid.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/kobject_ns.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/stat.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/stat.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/generated/uapi/asm/stat.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/asm-generic/stat.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/compat.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/compat.h \
    $(wildcard include/config/COMPAT_FOR_U64_ALIGNMENT) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/sched/task_stack.h \
    $(wildcard include/config/STACK_GROWSUP) \
    $(wildcard include/config/DEBUG_STACK_USAGE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/magic.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/stat.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/sched/cpufreq.h \
    $(wildcard include/config/CPU_FREQ) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/sched/topology.h \
    $(wildcard include/config/SCHED_CLUSTER) \
    $(wildcard include/config/SCHED_MC) \
    $(wildcard include/config/CPU_FREQ_GOV_SCHEDUTIL) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/sched/idle.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/sched/sd_flags.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/ioport.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/klist.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/pm.h \
    $(wildcard include/config/VT_CONSOLE_SLEEP) \
    $(wildcard include/config/CXL_SUSPEND) \
    $(wildcard include/config/PM_CLK) \
    $(wildcard include/config/PM_GENERIC_DOMAINS) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/device/bus.h \
    $(wildcard include/config/ACPI) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/device/class.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/device/devres.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/device/driver.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/module.h \
    $(wildcard include/config/MODULES_TREE_LOOKUP) \
    $(wildcard include/config/STACKTRACE_BUILD_ID) \
    $(wildcard include/config/ARCH_USES_CFI_TRAPS) \
    $(wildcard include/config/MODULE_SIG) \
    $(wildcard include/config/KALLSYMS) \
    $(wildcard include/config/BPF_EVENTS) \
    $(wildcard include/config/DEBUG_INFO_BTF_MODULES) \
    $(wildcard include/config/EVENT_TRACING) \
    $(wildcard include/config/KPROBES) \
    $(wildcard include/config/MODULE_UNLOAD) \
    $(wildcard include/config/CONSTRUCTORS) \
    $(wildcard include/config/FUNCTION_ERROR_INJECTION) \
    $(wildcard include/config/MITIGATION_RETPOLINE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/buildid.h \
    $(wildcard include/config/VMCORE_INFO) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/kmod.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/umh.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/sysctl.h \
    $(wildcard include/config/SYSCTL) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/sysctl.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/elf.h \
    $(wildcard include/config/ARCH_HAVE_EXTRA_ELF_NOTES) \
    $(wildcard include/config/ARCH_USE_GNU_PROPERTY) \
    $(wildcard include/config/ARCH_HAVE_ELF_PROT) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/elf.h \
    $(wildcard include/config/COMPAT_VDSO) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/generated/asm/user.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/user.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/elf.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/elf-em.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/fs.h \
    $(wildcard include/config/FANOTIFY_ACCESS_PERMISSIONS) \
    $(wildcard include/config/READ_ONLY_THP_FOR_FS) \
    $(wildcard include/config/FS_POSIX_ACL) \
    $(wildcard include/config/CGROUP_WRITEBACK) \
    $(wildcard include/config/IMA) \
    $(wildcard include/config/FILE_LOCKING) \
    $(wildcard include/config/FSNOTIFY) \
    $(wildcard include/config/EPOLL) \
    $(wildcard include/config/UNICODE) \
    $(wildcard include/config/FS_ENCRYPTION) \
    $(wildcard include/config/FS_VERITY) \
    $(wildcard include/config/QUOTA) \
    $(wildcard include/config/FS_DAX) \
    $(wildcard include/config/BLOCK) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/vfsdebug.h \
    $(wildcard include/config/DEBUG_VFS) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/wait_bit.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/kdev_t.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/kdev_t.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/dcache.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/rculist.h \
    $(wildcard include/config/PROVE_RCU_LIST) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/rculist_bl.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/list_bl.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/bit_spinlock.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/lockref.h \
    $(wildcard include/config/ARCH_USE_CMPXCHG_LOCKREF) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/stringhash.h \
    $(wildcard include/config/DCACHE_WORD_ACCESS) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/path.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/list_lru.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/shrinker.h \
    $(wildcard include/config/SHRINKER_DEBUG) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/pid.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/capability.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/capability.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/semaphore.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/fcntl.h \
    $(wildcard include/config/ARCH_32BIT_OFF_T) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/fcntl.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/uapi/asm/fcntl.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/asm-generic/fcntl.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/openat2.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/migrate_mode.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/percpu-rwsem.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/rcuwait.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/sched/signal.h \
    $(wildcard include/config/SCHED_AUTOGROUP) \
    $(wildcard include/config/BSD_PROCESS_ACCT) \
    $(wildcard include/config/TASKSTATS) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/signal.h \
    $(wildcard include/config/DYNAMIC_SIGFRAME) \
    $(wildcard include/config/PROC_FS) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/sched/jobctl.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/sched/task.h \
    $(wildcard include/config/HAVE_EXIT_THREAD) \
    $(wildcard include/config/ARCH_WANTS_DYNAMIC_TASK_STRUCT) \
    $(wildcard include/config/HAVE_ARCH_THREAD_STRUCT_WHITELIST) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/uaccess.h \
    $(wildcard include/config/ARCH_HAS_SUBPAGE_FAULTS) \
    $(wildcard include/config/HARDENED_USERCOPY) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/fault-inject-usercopy.h \
    $(wildcard include/config/FAULT_INJECTION_USERCOPY) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/ucopysize.h \
    $(wildcard include/config/HARDENED_USERCOPY_DEFAULT_ON) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/uaccess.h \
    $(wildcard include/config/CC_HAS_ASM_GOTO_OUTPUT) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/kernel-pgtable.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/asm-extable.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/extable.h \
    $(wildcard include/config/BPF_JIT) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/access_ok.h \
    $(wildcard include/config/ALTERNATE_USER_ADDRESS_SPACE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/cred.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/key.h \
    $(wildcard include/config/KEY_NOTIFICATIONS) \
    $(wildcard include/config/NET) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/assoc_array.h \
    $(wildcard include/config/ASSOCIATIVE_ARRAY) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/sched/user.h \
    $(wildcard include/config/VFIO_PCI_ZDEV_KVM) \
    $(wildcard include/config/IOMMUFD) \
    $(wildcard include/config/WATCH_QUEUE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/posix-timers.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/alarmtimer.h \
    $(wildcard include/config/RTC_CLASS) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/hrtimer.h \
    $(wildcard include/config/HIGH_RES_TIMERS) \
    $(wildcard include/config/TIME_LOW_RES) \
    $(wildcard include/config/TIMERFD) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/hrtimer_defs.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/timerqueue.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/rcuref.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/rcu_sync.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/delayed_call.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/errseq.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/ioprio.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/sched/rt.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/iocontext.h \
    $(wildcard include/config/BLK_ICQ) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/ioprio.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/fs_types.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/mount.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/mnt_idmapping.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/rw_hint.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/file_ref.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/unicode.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/fs.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/quota.h \
    $(wildcard include/config/QUOTA_NETLINK_INTERFACE) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/dqblk_xfs.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/dqblk_v1.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/dqblk_v2.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/dqblk_qtree.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/projid.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/uapi/linux/quota.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/moduleparam.h \
    $(wildcard include/config/ALPHA) \
    $(wildcard include/config/PPC64) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/rbtree_latch.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/error-injection.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/error-injection.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/dynamic_debug.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/module.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/asm-generic/module.h \
    $(wildcard include/config/HAVE_MOD_ARCH_SPECIFIC) \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/arch/arm64/include/asm/device.h \
  /work/github/pvr-linux-gitlab/build_linux/linux_v6.18.6/include/linux/pm_wakeup.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/include/pvr_bridge.h \
  /work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/mm_bridge/common_mm_bridge.h \
  /work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/mmextmem_bridge/common_mmextmem_bridge.h \
  /work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/cmm_bridge/common_cmm_bridge.h \
  /work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/dmabuf_bridge/common_dmabuf_bridge.h \
  /work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/cache_bridge/common_cache_bridge.h \
  /work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/srvcore_bridge/common_srvcore_bridge.h \
  /work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/sync_bridge/common_sync_bridge.h \
  /work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/pvrtl_bridge/common_pvrtl_bridge.h \
  /work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/devicememhistory_bridge/common_devicememhistory_bridge.h \
  /work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/synctracking_bridge/common_synctracking_bridge.h \
  /work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/di_bridge/common_di_bridge.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/include/pvr_dicommon.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/include/rgx_bridge.h \
  /work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/rgxta3d_bridge/common_rgxta3d_bridge.h \
  /work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/rgxcmp_bridge/common_rgxcmp_bridge.h \
  /work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/rgxtq2_bridge/common_rgxtq2_bridge.h \
  /work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/rgxfwdbg_bridge/common_rgxfwdbg_bridge.h \
  /work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/rgxhwperf_bridge/common_rgxhwperf_bridge.h \
  /work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/rgxregconfig_bridge/common_rgxregconfig_bridge.h \
  /work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/rgxtimerquery_bridge/common_rgxtimerquery_bridge.h \
  /work/github/pvr-linux-gitlab/rogue_km/generated/volcanic/rgxray_bridge/common_rgxray_bridge.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/system/volcanic/include/dma_support.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/server/include/pdump_km.h \
  /work/github/pvr-linux-gitlab/rogue_km/services/server/include/sync_fallback_server.h \

generated/volcanic/sync_bridge/client_sync_direct_bridge.o: $(deps_generated/volcanic/sync_bridge/client_sync_direct_bridge.o)

$(deps_generated/volcanic/sync_bridge/client_sync_direct_bridge.o):
